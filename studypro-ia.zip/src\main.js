import './style.css'

/* =========================================================
   STUDYPRO IA
   Versión reorganizada
   ========================================================= */

const STORAGE_KEY = 'studypro_ia_v4'

const materias = [
  'Matemática',
  'Comunicación',
  'Ciencia y Tecnología',
  'Historia',
  'Inglés'
]

const gameNames = {
  quiz: 'Quiz escolar',
  math: 'Desafío matemático',
  science: 'Laboratorio científico',
  memory: 'Memoria',
  word: 'Palabra secreta',
  quick: 'Reto rápido',
  mixed: 'Reto mixto'
}

const defaultState = {
  xp: 0,
  coins: 100,
  level: 1,
  streak: 0,
  lastActivity: null,

  tareas: [],
  notas: [],
  animo: null,
  diario: [],

  avatar: {
    skin: '#f1c29b',
    hair: '#3b2418',
    shirt: '#6d4aff',
    pants: '#25324a',
    hairType: 'spiky',
    shirtType: 'hoodie',
    accessory: 'none',
    accessory2: 'none',
    background: '#eee7ff'
  },

  settings: {
    dark: false,
    sound: true,
    language: 'Español',
    animations: true,
    compact: false
  },

  records: {
    quiz: 0,
    math: 0,
    science: 0,
    memory: 0,
    word: 0,
    quick: 0,
    mixed: 0
  }
}

let state = loadState()
let currentPage = 'inicio'
let currentCalendarDate = new Date()

/* =========================================================
   UTILIDADES
   ========================================================= */

function cloneDefault() {
  return JSON.parse(JSON.stringify(defaultState))
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')

    if (!saved) {
      return cloneDefault()
    }

    return {
      ...cloneDefault(),
      ...saved,

      avatar: {
        ...defaultState.avatar,
        ...(saved.avatar || {})
      },

      settings: {
        ...defaultState.settings,
        ...(saved.settings || {})
      },

      records: {
        ...defaultState.records,
        ...(saved.records || {})
      },

      tareas: Array.isArray(saved.tareas) ? saved.tareas : [],
      notas: Array.isArray(saved.notas) ? saved.notas : [],
      diario: Array.isArray(saved.diario) ? saved.diario : []
    }
  } catch (error) {
    console.warn('No se pudo cargar el progreso:', error)
    return cloneDefault()
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
}

function escapeHTML(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
}

function formatDate(date = new Date()) {
  return date.toLocaleDateString('es-PE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}

function formatTime(date = new Date()) {
  return date.toLocaleTimeString('es-PE', {
    hour: '2-digit',
    minute: '2-digit'
  })
}

function dateKey(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`
}

function todayKey() {
  return dateKey(new Date())
}

function greeting() {
  const hour = new Date().getHours()

  if (hour < 12) return '¡Buenos días! ☀️'
  if (hour < 19) return '¡Buenas tardes! 🌤️'

  return '¡Buenas noches! 🌙'
}

function showToast(message) {
  document.querySelector('.toast')?.remove()

  const toast = document.createElement('div')

  toast.className = 'toast'
  toast.textContent = message

  document.body.appendChild(toast)

  requestAnimationFrame(() => {
    toast.classList.add('show')
  })

  setTimeout(() => {
    toast.classList.remove('show')

    setTimeout(() => {
      toast.remove()
    }, 300)
  }, 2600)
}

function playFeedback(type = 'success') {
  if (!state.settings.sound) return

  // No dependemos de archivos externos.
  // Un sonido sencillo usando Web Audio.
  try {
    const AudioContext =
      window.AudioContext || window.webkitAudioContext

    if (!AudioContext) return

    const audio = new AudioContext()
    const oscillator = audio.createOscillator()
    const gain = audio.createGain()

    oscillator.frequency.value =
      type === 'success'
        ? 620
        : type === 'error'
          ? 180
          : 420

    oscillator.type = 'sine'

    gain.gain.setValueAtTime(0.04, audio.currentTime)
    gain.gain.exponentialRampToValueAtTime(
      0.001,
      audio.currentTime + 0.15
    )

    oscillator.connect(gain)
    gain.connect(audio.destination)

    oscillator.start()
    oscillator.stop(audio.currentTime + 0.15)
  } catch {
    // El sonido es opcional.
  }
}

/* =========================================================
   XP / NIVEL / RACHA
   ========================================================= */

function xpNeeded() {
  return 100 + (state.level - 1) * 50
}

function addXP(amount) {
  if (!Number.isFinite(amount) || amount <= 0) return

  state.xp += amount

  let required = xpNeeded()

  while (state.xp >= required) {
    state.xp -= required
    state.level += 1
    state.coins += 25

    showToast(
      `🎉 ¡Nivel ${state.level}! +25 monedas`
    )

    required = xpNeeded()
  }

  saveState()
}

function addCoins(amount) {
  state.coins = Math.max(0, state.coins + amount)
  saveState()
}

function updateStreak() {
  const today = todayKey()

  if (state.lastActivity === today) {
    return
  }

  if (!state.lastActivity) {
    state.streak = 1
  } else {
    const previous = new Date(`${state.lastActivity}T00:00:00`)
    const current = new Date(`${today}T00:00:00`)

    const difference =
      Math.round(
        (current - previous) / (1000 * 60 * 60 * 24)
      )

    if (difference === 1) {
      state.streak += 1
    } else if (difference > 1) {
      state.streak = 1
    }
  }

  state.lastActivity = today

  saveState()
}

/* =========================================================
   AVATAR
   ========================================================= */

function avatarSVG(size = 160) {
  const a = state.avatar

  const hair = getHairSVG(a)

  const shirt = getShirtSVG(a)

  const pants = `
    <path
      d="M65 165 L78 130 L100 140 L122 130 L135 165
      L123 190 L100 165 L77 190Z"
      fill="${a.pants}"
      stroke="#202536"
      stroke-width="4"
    />
  `

  let accessory = ''

  /* Accesorio principal */

  switch (a.accessory) {
    case 'glasses':
      accessory += `
        <circle cx="77" cy="82" r="14"
          fill="none"
          stroke="#202536"
          stroke-width="4"/>

        <circle cx="123" cy="82" r="14"
          fill="none"
          stroke="#202536"
          stroke-width="4"/>

        <path d="M91 82 L109 82"
          stroke="#202536"
          stroke-width="4"/>
      `
      break

    case 'cap':
      accessory += `
        <path
          d="M54 58 Q100 25 146 58
          L146 72 L54 72Z"
          fill="${a.shirt}"
          stroke="#202536"
          stroke-width="4"
        />

        <path
          d="M135 67 L166 73"
          stroke="#202536"
          stroke-width="8"
          stroke-linecap="round"
        />
      `
      break

    case 'headphones':
      accessory += `
        <path
          d="M55 82 Q55 34 100 34
          Q145 34 145 82"
          fill="none"
          stroke="#202536"
          stroke-width="8"
        />

        <rect x="46" y="74"
          width="20"
          height="34"
          rx="9"
          fill="${a.shirt}"/>

        <rect x="134" y="74"
          width="20"
          height="34"
          rx="9"
          fill="${a.shirt}"/>
      `
      break

    case 'crown':
      accessory += `
        <path
          d="M62 51 L72 29 L88 47
          L100 24 L112 47
          L128 29 L138 51Z"
          fill="#f5c542"
          stroke="#202536"
          stroke-width="3"
        />
      `
      break

    case 'headband':
      accessory += `
        <path
          d="M49 65 Q100 31 151 65"
          fill="none"
          stroke="${a.shirt}"
          stroke-width="9"
        />
      `
      break

    case 'visor':
      accessory += `
        <path
          d="M55 58 Q100 38 145 58
          L145 67 L55 67Z"
          fill="${a.shirt}"
          stroke="#202536"
          stroke-width="3"
        />
      `
      break
  }

  /* Accesorio secundario */

  switch (a.accessory2) {
    case 'backpack':
      accessory += `
        <path
          d="M37 130 Q22 130 25 174
          L53 174 L58 130Z"
          fill="#4f46e5"
          stroke="#202536"
          stroke-width="4"
        />
      `
      break

    case 'star':
      accessory += `
        <path
          d="M100 8
          L105 19
          L117 20
          L108 28
          L111 40
          L100 34
          L89 40
          L92 28
          L83 20
          L95 19Z"
          fill="#f5c542"
        />
      `
      break

    case 'badge':
      accessory += `
        <circle cx="138" cy="142" r="12"
          fill="#f5c542"
          stroke="#202536"
          stroke-width="3"/>

        <text x="138" y="147"
          text-anchor="middle"
          font-size="12"
          font-weight="bold">
          ★
        </text>
      `
      break

    case 'tie':
      accessory += `
        <path
          d="M93 125 L107 125
          L112 158 L100 171
          L88 158Z"
          fill="#ef4444"
          stroke="#202536"
          stroke-width="3"
        />
      `
      break

    case 'scarf':
      accessory += `
        <path
          d="M65 115 Q100 135 135 115
          L130 137 Q100 153 70 137Z"
          fill="${a.shirt}"
          stroke="#202536"
          stroke-width="3"
        />
      `
      break
  }

  return `
    <svg
      viewBox="0 0 200 210"
      width="${size}"
      height="${size * 1.05}"
      class="avatar-svg"
      role="img"
      aria-label="Avatar personalizado de StudyPro"
    >

      <ellipse
        cx="100"
        cy="199"
        rx="65"
        ry="8"
        fill="#000"
        opacity=".12"
      />

      ${pants}

      ${shirt}

      <rect
        x="77"
        y="103"
        width="46"
        height="32"
        rx="16"
        fill="${a.skin}"
      />

      <circle
        cx="100"
        cy="80"
        r="55"
        fill="${a.skin}"
        stroke="#202536"
        stroke-width="4"
      />

      ${hair}

      <circle cx="78" cy="83" r="5" fill="#202536"/>
      <circle cx="122" cy="83" r="5" fill="#202536"/>

      <path
        d="M91 104 Q100 111 109 104"
        fill="none"
        stroke="#202536"
        stroke-width="3"
        stroke-linecap="round"
      />

      ${accessory}

    </svg>
  `
}

function getHairSVG(a) {
  if (a.hairType === 'short') {
    return `
      <path
        d="M48 73 Q48 27 100 27
        Q152 27 152 73
        Q135 52 118 56
        Q100 38 82 56
        Q65 52 48 73Z"
        fill="${a.hair}"
      />
    `
  }

  if (a.hairType === 'curly') {
    return `
      <circle cx="65" cy="56" r="24" fill="${a.hair}"/>
      <circle cx="88" cy="39" r="25" fill="${a.hair}"/>
      <circle cx="115" cy="39" r="25" fill="${a.hair}"/>
      <circle cx="138" cy="56" r="24" fill="${a.hair}"/>
    `
  }

  if (a.hairType === 'long') {
    return `
      <path
        d="M47 92 Q35 20 100 25
        Q165 20 153 92
        L135 115 L130 63
        Q100 45 70 63
        L65 115Z"
        fill="${a.hair}"
      />
    `
  }

  return `
    <path
      d="M45 80 Q45 20 100 25
      Q155 20 155 80
      L140 60 L128 78
      L115 55 L100 76
      L82 53 L65 78Z"
      fill="${a.hair}"
    />
  `
}

function getShirtSVG(a) {
  if (a.shirtType === 'sports') {
    return `
      <path
        d="M43 170 L59 120
        Q100 105 141 120
        L157 170Z"
        fill="${a.shirt}"
        stroke="#202536"
        stroke-width="4"
      />

      <path
        d="M84 122 L100 150 L116 122"
        fill="none"
        stroke="#fff"
        stroke-width="5"
      />
    `
  }

  if (a.shirtType === 'jacket') {
    return `
      <path
        d="M42 170 L60 120
        L140 120 L158 170Z"
        fill="${a.shirt}"
        stroke="#202536"
        stroke-width="4"
      />

      <path
        d="M100 120 L100 170"
        stroke="#fff"
        stroke-width="4"
      />
    `
  }

  if (a.shirtType === 'uniform') {
    return `
      <path
        d="M42 170 L60 120
        Q100 108 140 120
        L158 170Z"
        fill="${a.shirt}"
        stroke="#202536"
        stroke-width="4"
      />

      <rect
        x="83"
        y="134"
        width="34"
        height="22"
        rx="4"
        fill="#fff"
        opacity=".9"
      />

      <text
        x="100"
        y="150"
        text-anchor="middle"
        font-size="9"
        font-weight="bold">
        SP
      </text>
    `
  }

  return `
    <path
      d="M42 170 L58 120
      Q100 105 142 120
      L158 170Z"
      fill="${a.shirt}"
      stroke="#202536"
      stroke-width="4"
    />

    <path
      d="M78 123 Q100 145 122 123"
      fill="none"
      stroke="#202536"
      stroke-width="4"
    />
  `
}

/* =========================================================
   NAVEGACIÓN
   ========================================================= */

function navItem(id, icon, title) {
  return `
    <button
      class="nav-item ${currentPage === id ? 'active' : ''}"
      onclick="navigate('${id}')"
    >
      <span>${icon}</span>
      <b>${title}</b>
    </button>
  `
}

/* =========================================================
   RENDER PRINCIPAL
   ========================================================= */

function render() {
  document.body.classList.toggle(
    'dark-mode',
    Boolean(state.settings.dark)
  )

  document.body.classList.toggle(
    'compact-mode',
    Boolean(state.settings.compact)
  )

  const app = document.querySelector('#app')

  if (!app) return

  app.innerHTML = `
    <div class="app-shell">

      <aside class="sidebar" id="sidebar">

        <div class="brand">

          <div class="brand-logo">
            <span>SP</span>
          </div>

          <div>
            <strong>StudyPro IA</strong>
            <small>Tu espacio escolar</small>
          </div>

        </div>

        <button
          class="close-menu"
          onclick="toggleMenu()"
          aria-label="Cerrar menú"
        >
          ×
        </button>

        <nav>

          ${navItem('inicio', '🏠', 'Inicio')}
          ${navItem('tutor', '🧠', 'Tutor IA')}
          ${navItem('tareas', '📚', 'Tareas')}
          ${navItem('juegos', '🎮', 'Juegos')}
          ${navItem('avatar', '👤', 'Mi avatar')}
          ${navItem('libreta', '📖', 'Mi libreta')}
          ${navItem('bienestar', '💙', 'Bienestar')}
          ${navItem('calendario', '📅', 'Calendario')}
          ${navItem('progreso', '🏆', 'Mi progreso')}
          ${navItem('config', '⚙️', 'Configuración')}

        </nav>

        <div class="sidebar-progress">

          <small>NIVEL ${state.level}</small>

          <strong>
            ${state.xp} / ${xpNeeded()} XP
          </strong>

          <div class="progress-bar">
            <span
              style="
                width:${Math.min(
                  100,
                  (state.xp / xpNeeded()) * 100
                )}%
              "
            ></span>
          </div>

          <div class="currency">
            🪙 ${state.coins}
          </div>

        </div>

      </aside>

      <div
        class="mobile-overlay"
        onclick="toggleMenu()"
      ></div>

      <main class="main-content">

        <header class="topbar">

          <button
            class="menu-button"
            onclick="toggleMenu()"
            aria-label="Abrir menú"
          >
            ☰
          </button>

          <div>
            <p class="top-greeting">
              ${greeting()}
            </p>

            <h1>StudyPro IA</h1>
          </div>

          <div class="top-stats">

            <div class="stat-pill">
              ⭐ ${state.xp} XP
            </div>

            <div class="stat-pill">
              🔥 ${state.streak}
            </div>

            <div class="stat-pill">
              🪙 ${state.coins}
            </div>

            <button
              class="mini-avatar"
              onclick="navigate('avatar')"
              aria-label="Abrir avatar"
            >
              ${avatarSVG(50)}
            </button>

          </div>

        </header>

        <section class="page-container">
          ${getPage()}
        </section>

      </main>

    </div>
  `

  if (currentPage === 'tareas') {
    renderTasksEvents()
  }

  if (currentPage === 'tutor') {
    renderTutorEvents()
  }

  if (currentPage === 'libreta') {
    renderNotesEvents()
  }

  if (currentPage === 'bienestar') {
    renderWellnessEvents()
  }

  if (currentPage === 'config') {
    renderConfigEvents()
  }
}

function getPage() {
  switch (currentPage) {
    case 'inicio':
      return homePage()

    case 'tutor':
      return tutorPage()

    case 'tareas':
      return tasksPage()

    case 'juegos':
      return gamesPage()

    case 'avatar':
      return avatarPage()

    case 'libreta':
      return notesPage()

    case 'bienestar':
      return wellnessPage()

    case 'calendario':
      return calendarPage()

    case 'progreso':
      return progressPage()

    case 'config':
      return configPage()

    default:
      return homePage()
  }
}

/* =========================================================
   INICIO
   ========================================================= */

function homePage() {
  const pending = state.tareas.filter(
    task => !task.completed
  )

  return `
    <div class="home-grid">

      <section class="hero-card">

        <div class="hero-text">

          <span class="eyebrow">
            TU ESPACIO ESCOLAR ✨
          </span>

          <h2>
            Organiza,
            <span>aprende</span>
            y diviértete.
          </h2>

          <p>
            StudyPro IA reúne tus estudios,
            tareas, juegos, apuntes y bienestar
            en un solo lugar.
          </p>

          <div class="hero-actions">

            <button
              class="primary-btn"
              onclick="navigate('tutor')"
            >
              🧠 Estudiar
            </button>

            <button
              class="secondary-btn"
              onclick="navigate('juegos')"
            >
              🎮 Jugar
            </button>

          </div>

        </div>

        <div class="hero-art">

          <div class="floating-book">
            📚
          </div>

          <div class="floating-star">
            ✦
          </div>

          <div class="desk">
            <span>📖</span>
            <span>✏️</span>
            <span>📝</span>
          </div>

          <div class="student-illustration">
            ${avatarSVG(210)}
          </div>

        </div>

      </section>

      <section class="welcome-card">

        <div class="welcome-avatar">
          ${avatarSVG(150)}
        </div>

        <h3>
          Mi avatar
        </h3>

        <p>
          Nivel ${state.level}
          · ${state.xp} XP
        </p>

        <button
          onclick="navigate('avatar')"
        >
          🎨 Personalizar
        </button>

      </section>

      <section class="dashboard-card tasks-preview">

        <div class="card-heading">

          <h3>
            📋 Próximas tareas
          </h3>

          <button onclick="navigate('tareas')">
            Ver todas →
          </button>

        </div>

        ${
          pending.length === 0
            ? `
              <div class="empty-art">
                🎉
                <p>
                  ¡No tienes tareas pendientes!
                </p>
              </div>
            `
            : pending
                .slice(0, 4)
                .map(task => `
                  <div class="mini-task">

                    <span class="task-dot"></span>

                    <div>
                      <strong>
                        ${escapeHTML(task.name)}
                      </strong>

                      <small>
                        ${escapeHTML(task.subject)}
                        · ${escapeHTML(task.date || 'Sin fecha')}
                      </small>
                    </div>

                  </div>
                `)
                .join('')
        }

      </section>

      <section class="dashboard-card games-preview">

        <div class="card-heading">

          <h3>
            🎮 Practica
          </h3>

          <button onclick="navigate('juegos')">
            Ver todos →
          </button>

        </div>

        <div class="game-mini-grid">

          <button onclick="startGame('quiz')">
            🧠 Quiz
          </button>

          <button onclick="startGame('math')">
            🔢 Matemática
          </button>

          <button onclick="startGame('science')">
            🔬 Ciencia
          </button>

          <button onclick="startGame('memory')">
            🧩 Memoria
          </button>

        </div>

      </section>

      <section class="dashboard-card mood-preview">

        <div class="card-heading">
          <h3>💙 ¿Cómo estás hoy?</h3>
        </div>

        <p>
          Registrar tu estado puede ayudarte a
          reconocer cómo ha sido tu día.
        </p>

        <div class="mood-row">

          ${[
            ['😊', 'Muy bien'],
            ['🙂', 'Bien'],
            ['😐', 'Normal'],
            ['😕', 'Algo difícil'],
            ['😣', 'Necesito una pausa']
          ]
            .map(([emoji, label]) => `
              <button
                onclick="quickMood('${emoji}')"
                class="${state.animo === emoji ? 'selected' : ''}"
                title="${label}"
              >
                ${emoji}
              </button>
            `)
            .join('')}

        </div>

      </section>

      <section class="dashboard-card notebook-preview">

        <div class="card-heading">

          <h3>
            📖 Mi libreta
          </h3>

          <button onclick="navigate('libreta')">
            Abrir →
          </button>

        </div>

        ${
          state.notas.length
            ? state.notas
                .slice(0, 3)
                .map(note => `
                  <div class="note-mini">

                    <span>📝</span>

                    <div>
                      <strong>
                        ${escapeHTML(note.title)}
                      </strong>

                      <small>
                        ${note.date} · ${note.time}
                      </small>
                    </div>

                  </div>
                `)
                .join('')
            : `
              <div class="empty-art">
                📓
                <p>
                  Aún no tienes apuntes.
                </p>
              </div>
            `
        }

      </section>

      <section class="tip-card">

        <div class="tip-icon">
          💡
        </div>

        <div>
          <small>
            CONSEJO DEL DÍA
          </small>

          <h3>
            ${dailyTip()}
          </h3>
        </div>

      </section>

    </div>
  `
}

function dailyTip() {
  const tips = [
    'Divide una tarea grande en pasos pequeños.',
    'Estudiar un poco cada día suele ser más manejable que hacerlo todo al final.',
    'Si no entiendes algo, intenta explicarlo con tus propias palabras.',
    'Haz pausas breves cuando notes que tu concentración está bajando.',
    'Dormir bien también forma parte de aprender.',
    'Organizar tus pendientes puede reducir el estrés escolar.',
    'Equivocarte en una pregunta también puede enseñarte algo.',
    'Antes de un examen, practica recordando sin mirar tus apuntes.',
    'Mantén cerca solamente lo que necesitas para estudiar.',
    'Celebra los pequeños avances.'
  ]

  return tips[
    new Date().getDate() % tips.length
  ]
}

/* =========================================================
   TUTOR
   ========================================================= */

function tutorPage() {
  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          APRENDE PASO A PASO
        </span>

        <h2>
          🧠 Tutor IA
        </h2>

        <p>
          Pregunta sobre una materia y recibe
          una explicación orientativa.
        </p>

      </div>

    </div>

    <div class="tutor-layout">

      <section class="tutor-card-large">

        <div class="ai-character">
          <div class="ai-head">
            <span>• •</span>
            <strong>AI</strong>
          </div>
        </div>

        <h3>
          ¿Qué quieres aprender?
        </h3>

        <select id="tutorSubject">
          ${materias
            .map(
              materia =>
                `<option>${materia}</option>`
            )
            .join('')}
        </select>

        <textarea
          id="tutorQuestion"
          placeholder="Ejemplo: ¿Cómo se resuelve una ecuación de primer grado?"
        ></textarea>

        <button
          class="primary-btn"
          id="askTutor"
        >
          🚀 Preguntar
        </button>

        <div
          id="tutorResponse"
          class="ai-response"
        >
          <strong>
            🤖 StudyPro:
          </strong>

          <p>
            Escribe una pregunta para comenzar.
          </p>
        </div>

      </section>

      <aside class="study-help">

        <h3>
          📚 Accesos rápidos
        </h3>

        <button
          onclick="tutorExample('Explícame las fracciones de forma sencilla')"
        >
          ➗ Fracciones
        </button>

        <button
          onclick="tutorExample('Explícame la fotosíntesis')"
        >
          🌱 Fotosíntesis
        </button>

        <button
          onclick="tutorExample('¿Qué es un sustantivo?')"
        >
          ✍️ Comunicación
        </button>

        <button
          onclick="tutorExample('Ayúdame con vocabulario básico en inglés')"
        >
          🇬🇧 Inglés
        </button>

        <button
          onclick="tutorExample('¿Qué es una ecuación de primer grado?')"
        >
          🔢 Ecuaciones
        </button>

        <div class="info-box">
          💡 Actualmente StudyPro funciona
          sin una API externa. Cuando conectes
          una IA real, este mismo tutor podrá
          generar respuestas mucho más amplias.
        </div>

      </aside>

    </div>
  `
}

function tutorExample(text) {
  const input =
    document.querySelector('#tutorQuestion')

  if (!input) return

  input.value = text
  input.focus()
}

function getTutorAnswer(question, subject) {
  const q = question.toLowerCase()

  if (
    subject === 'Matemática' &&
    (q.includes('ecuación') ||
      q.includes('ecuacion'))
  ) {
    return `
      <h4>🔢 Ecuación de primer grado</h4>

      <p>
        Una ecuación es una igualdad que contiene
        una cantidad desconocida.
      </p>

      <p>
        Por ejemplo:
        <strong>x + 5 = 12</strong>
      </p>

      <p>
        Para encontrar x, restamos 5 a ambos lados:
        <strong>x = 7</strong>.
      </p>

      <div class="search-help">
        📌 Consejo: comprueba la respuesta
        reemplazando x en la ecuación original.
      </div>
    `
  }

  if (
    subject === 'Matemática' &&
    (q.includes('fracción') ||
      q.includes('fraccion'))
  ) {
    return `
      <h4>➗ Fracciones</h4>

      <p>
        Una fracción representa una parte de un todo.
      </p>

      <p>
        En <strong>3/4</strong>, el 3 es el numerador
        y el 4 es el denominador.
      </p>

      <div class="search-help">
        💡 Para sumar fracciones con el mismo
        denominador, suma los numeradores y
        conserva el denominador.
      </div>
    `
  }

  if (
    subject === 'Ciencia y Tecnología' &&
    q.includes('fotosíntesis')
  ) {
    return `
      <h4>🌱 Fotosíntesis</h4>

      <p>
        Es el proceso mediante el cual las plantas
        producen alimento utilizando principalmente
        luz, agua y dióxido de carbono.
      </p>

      <p>
        Como resultado se produce glucosa y se libera
        oxígeno.
      </p>
    `
  }

  if (
    subject === 'Comunicación' &&
    (q.includes('sustantivo') ||
      q.includes('verbo') ||
      q.includes('adjetivo'))
  ) {
    return `
      <h4>✍️ Comunicación</h4>

      <p>
        Los sustantivos nombran personas, animales,
        lugares, objetos o ideas.
      </p>

      <p>
        Los verbos expresan acciones o estados.
      </p>

      <p>
        Los adjetivos describen características.
      </p>
    `
  }

  if (
    subject === 'Inglés' &&
    (q.includes('book') ||
      q.includes('vocabulario') ||
      q.includes('hello'))
  ) {
    return `
      <h4>🇬🇧 Inglés</h4>

      <p>
        <strong>Book</strong> significa libro.
      </p>

      <p>
        Algunas palabras básicas:
        <br>
        Hello = Hola
        <br>
        School = Escuela
        <br>
        Teacher = Profesor/a
        <br>
        Friend = Amigo/a
      </p>
    `
  }

  if (
    q.includes('hola') ||
    q.includes('buenos días') ||
    q.includes('buenas tardes') ||
    q.includes('buenas noches')
  ) {
    return `
      <h4>👋 ¡Hola!</h4>

      <p>
        ${greeting()}
      </p>

      <p>
        Soy el asistente de estudio de StudyPro.
        Puedes preguntarme sobre tus materias,
        organización o técnicas de estudio.
      </p>
    `
  }

  return `
    <h4>📚 Buena pregunta</h4>

    <p>
      Tu pregunta está relacionada con
      <strong>${escapeHTML(subject)}</strong>.
    </p>

    <p>
      En esta versión todavía no estoy conectado
      a una IA externa, así que no quiero inventarte
      una respuesta.
    </p>

    <div class="search-help">

      🔎 Puedes buscar la pregunta exacta en:

      <ul>
        <li>Tu libro o material escolar.</li>
        <li>La biblioteca de tu colegio.</li>
        <li>Una plataforma educativa confiable.</li>
        <li>Preguntando a tu profesor.</li>
      </ul>

      <strong>
        Pregunta:
      </strong>

      ${escapeHTML(question)}

    </div>
  `
}

function renderTutorEvents() {
  const button =
    document.querySelector('#askTutor')

  if (!button) return

  button.addEventListener('click', () => {
    const question =
      document.querySelector('#tutorQuestion')
        ?.value
        .trim()

    const subject =
      document.querySelector('#tutorSubject')
        ?.value

    const response =
      document.querySelector('#tutorResponse')

    if (!question || !response) {
      return
    }

    response.innerHTML = `
      <strong>
        🤖 StudyPro · ${escapeHTML(subject)}
      </strong>

      <div class="tutor-answer">
        ${getTutorAnswer(question, subject)}
      </div>
    `

    addXP(2)
    updateStreak()
    playFeedback('success')
  })
}

/* =========================================================
   TAREAS
   ========================================================= */

function tasksPage() {
  const pending =
    state.tareas.filter(
      task => !task.completed
    ).length

  return `
    <div class="section-header">

      <div>
        <span class="eyebrow">
          ORGANIZACIÓN
        </span>

        <h2>
          📚 Mis tareas
        </h2>

        <p>
          Organiza trabajos, exámenes y pendientes.
        </p>
      </div>

      <div class="header-counter">
        ${pending} pendientes
      </div>

    </div>

    <div class="tasks-layout">

      <section class="form-card">

        <h3>
          ➕ Nueva tarea
        </h3>

        <input
          id="taskName"
          placeholder="Ej: Exposición de Historia"
        >

        <select id="taskSubject">
          ${materias
            .map(
              materia =>
                `<option>${materia}</option>`
            )
            .join('')}
        </select>

        <input
          id="taskDate"
          type="date"
        >

        <select id="taskPriority">

          <option value="Alta">
            Alta
          </option>

          <option
            value="Media"
            selected
          >
            Media
          </option>

          <option value="Baja">
            Baja
          </option>

        </select>

        <button
          class="primary-btn"
          id="addTask"
        >
          ➕ Agregar tarea
        </button>

      </section>

      <section class="tasks-list-card">

        <h3>
          📌 Mis pendientes
        </h3>

        ${
          state.tareas.length === 0
            ? `
              <div class="big-empty">
                <div>🎒</div>
                <h3>
                  Todo despejado
                </h3>
                <p>
                  Agrega tu primera tarea.
                </p>
              </div>
            `
            : state.tareas
                .map(
                  (task, index) => `
                    <div
                      class="
                        task-item
                        ${task.completed ? 'completed' : ''}
                      "
                    >

                      <button
                        class="check-task"
                        onclick="toggleTask(${index})"
                      >
                        ${task.completed ? '✓' : ''}
                      </button>

                      <div class="task-content">

                        <strong>
                          ${escapeHTML(task.name)}
                        </strong>

                        <small>
                          ${escapeHTML(task.subject)}
                          ·
                          ${escapeHTML(
                            task.date || 'Sin fecha'
                          )}
                        </small>

                      </div>

                      <span
                        class="
                          priority
                          ${String(
                            task.priority || 'Media'
                          ).toLowerCase()}
                        "
                      >
                        ${escapeHTML(
                          task.priority || 'Media'
                        )}
                      </span>

                      <button
                        class="delete-btn"
                        onclick="deleteTask(${index})"
                        title="Eliminar tarea"
                      >
                        🗑️
                      </button>

                    </div>
                  `
                )
                .join('')
        }

      </section>

    </div>
  `
}

function renderTasksEvents() {
  document
    .querySelector('#addTask')
    ?.addEventListener('click', () => {

      const name =
        document.querySelector('#taskName')
          ?.value
          .trim()

      const subject =
        document.querySelector('#taskSubject')
          ?.value

      const date =
        document.querySelector('#taskDate')
          ?.value

      const priority =
        document.querySelector('#taskPriority')
          ?.value

      if (!name) {
        showToast(
          '✏️ Escribe el nombre de la tarea'
        )

        return
      }

      state.tareas.unshift({
        id: Date.now(),
        name,
        subject,
        date: date || 'Sin fecha',
        priority,
        completed: false,
        createdAt: new Date().toISOString()
      })

      saveState()

      addXP(5)
      updateStreak()

      showToast(
        '📚 Tarea agregada'
      )

      playFeedback('success')

      render()
    })
}

function toggleTask(index) {
  const task = state.tareas[index]

  if (!task) return

  task.completed = !task.completed

  if (task.completed) {
    addXP(15)
    addCoins(5)
    updateStreak()

    showToast(
      '🎉 ¡Tarea completada! +15 XP'
    )

    playFeedback('success')
  }

  saveState()
  render()
}

function deleteTask(index) {
  if (!state.tareas[index]) return

  if (
    !confirm(
      '¿Quieres eliminar esta tarea?'
    )
  ) {
    return
  }

  state.tareas.splice(index, 1)

  saveState()

  showToast(
    '🗑️ Tarea eliminada'
  )

  render()
}

/* =========================================================
   JUEGOS
   ========================================================= */

function gamesPage() {
  const games = [
    [
      'quiz',
      '🧠',
      'Quiz escolar',
      'Preguntas por materias'
    ],
    [
      'math',
      '🔢',
      'Desafío matemático',
      'Practica cálculos'
    ],
    [
      'science',
      '🔬',
      'Laboratorio científico',
      'Descubre ciencia'
    ],
    [
      'memory',
      '🧩',
      'Memoria',
      'Encuentra parejas'
    ],
    [
      'word',
      '🔤',
      'Palabra secreta',
      'Conceptos y vocabulario'
    ],
    [
      'quick',
      '⚡',
      'Reto rápido',
      'Responde rápidamente'
    ],
    [
      'mixed',
      '🏆',
      'Reto mixto',
      'Un poco de todo'
    ]
  ]

  return `
    <div class="section-header">

      <div>
        <span class="eyebrow">
          APRENDE JUGANDO
        </span>

        <h2>
          🎮 Zona de juegos
        </h2>

        <p>
          Practica, gana XP y supera tus récords.
        </p>
      </div>

    </div>

    <div class="games-grid">

      ${games
        .map(
          game => `
            <article class="game-card">

              <div class="game-art-big">
                ${game[1]}
              </div>

              <div>

                <span class="game-record">
                  🏆 Récord:
                  ${state.records[game[0]] || 0}
                </span>

                <h3>
                  ${game[2]}
                </h3>

                <p>
                  ${game[3]}
                </p>

                <button
                  class="primary-btn"
                  onclick="startGame('${game[0]}')"
                >
                  Jugar
                </button>

              </div>

            </article>
          `
        )
        .join('')}

    </div>

    <div id="gameArea"></div>
  `
}

function startGame(type) {
  if (!gameNames[type]) return

  if (!document.querySelector('#gameArea')) {
    currentPage = 'juegos'
    render()
  }

  const area =
    document.querySelector('#gameArea')

  if (!area) return

  if (type === 'memory') {
    memoryGame(area)
    return
  }

  const questions =
    getQuestions(type)

  let current = 0
  let score = 0

  function drawQuestion() {
    const q = questions[current]

    if (!q) return

    area.innerHTML = `
      <div class="active-game">

        <div class="game-top">

          <span>
            Pregunta
            ${current + 1}/${questions.length}
          </span>

          <span>
            ⭐ ${score}
          </span>

        </div>

        <div class="question-category">
          ${escapeHTML(q.subject)}
        </div>

        <h2>
          ${escapeHTML(q.question)}
        </h2>

        <div class="answers">

          ${q.answers
            .map(
              (answer, i) => `
                <button
                  data-answer="${i}"
                  class="game-answer"
                >
                  ${escapeHTML(answer)}
                </button>
              `
            )
            .join('')}

        </div>

      </div>
    `

    const buttons =
      area.querySelectorAll(
        '.game-answer'
      )

    buttons.forEach(button => {
      button.addEventListener(
        'click',
        () => {

          const index =
            Number(
              button.dataset.answer
            )

          buttons.forEach(
            b => (b.disabled = true)
          )

          if (index === q.correct) {
            score++

            button.classList.add(
              'correct'
            )

            showToast(
              '✅ ¡Correcto! +10 XP'
            )

            playFeedback('success')
          } else {
            button.classList.add(
              'wrong'
            )

            buttons[q.correct]
              ?.classList.add('correct')

            showToast(
              '💡 Casi. ¡Mira la respuesta correcta!'
            )

            playFeedback('error')
          }

          current++

          if (
            current >= questions.length
          ) {
            setTimeout(() => {
              finishGame(
                type,
                score,
                questions.length
              )
            }, 650)
          } else {
            setTimeout(
              drawQuestion,
              650
            )
          }
        }
      )
    })
  }

  drawQuestion()
}

function getQuestions(type) {
  const bank = {

    math: [
      {
        subject: 'Matemática',
        question: '¿Cuánto es 8 × 7?',
        answers: ['54', '56', '64', '48'],
        correct: 1
      },
      {
        subject: 'Matemática',
        question: 'Si x + 5 = 12, ¿cuánto vale x?',
        answers: ['5', '6', '7', '8'],
        correct: 2
      },
      {
        subject: 'Matemática',
        question: '¿Cuánto es 25% de 100?',
        answers: ['10', '20', '25', '50'],
        correct: 2
      },
      {
        subject: 'Matemática',
        question: '¿Cuál es el resultado de 9²?',
        answers: ['18', '72', '81', '90'],
        correct: 2
      },
      {
        subject: 'Matemática',
        question: '¿Cuánto es 144 ÷ 12?',
        answers: ['10', '12', '14', '16'],
        correct: 1
      },
      {
        subject: 'Matemática',
        question: '¿Cuál es un número primo?',
        answers: ['9', '15', '17', '21'],
        correct: 2
      }
    ],

    science: [
      {
        subject: 'Ciencia y Tecnología',
        question: '¿Qué necesitan las plantas para realizar fotosíntesis?',
        answers: [
          'Luz',
          'Plástico',
          'Metal',
          'Vidrio'
        ],
        correct: 0
      },
      {
        subject: 'Ciencia y Tecnología',
        question: '¿Qué órgano bombea la sangre?',
        answers: [
          'Pulmón',
          'Corazón',
          'Riñón',
          'Estómago'
        ],
        correct: 1
      },
      {
        subject: 'Ciencia y Tecnología',
        question: '¿En qué estado está el agua cuando se convierte en hielo?',
        answers: [
          'Líquido',
          'Gaseoso',
          'Sólido',
          'Plasma'
        ],
        correct: 2
      },
      {
        subject: 'Ciencia y Tecnología',
        question: '¿Qué planeta es conocido como el planeta rojo?',
        answers: [
          'Venus',
          'Marte',
          'Júpiter',
          'Mercurio'
        ],
        correct: 1
      }
    ],

    communication: [
      {
        subject: 'Comunicación',
        question: '¿Cuál es un sinónimo de rápido?',
        answers: [
          'Lento',
          'Veloz',
          'Débil',
          'Pequeño'
        ],
        correct: 1
      },
      {
        subject: 'Comunicación',
        question: '¿Qué palabra es un sustantivo?',
        answers: [
          'Correr',
          'Hermoso',
          'Escuela',
          'Rápidamente'
        ],
        correct: 2
      },
      {
        subject: 'Comunicación',
        question: '¿Cuál es un antónimo de grande?',
        answers: [
          'Enorme',
          'Gigante',
          'Pequeño',
          'Amplio'
        ],
        correct: 2
      }
    ],

    history: [
      {
        subject: 'Historia',
        question: '¿En qué continente se encuentra Perú?',
        answers: [
          'Europa',
          'Asia',
          'América',
          'África'
        ],
        correct: 2
      },
      {
        subject: 'Historia',
        question: '¿Cuál fue una gran civilización del antiguo Perú?',
        answers: [
          'Inca',
          'Romana',
          'Egipcia',
          'Griega'
        ],
        correct: 0
      }
    ],

    english: [
      {
        subject: 'Inglés',
        question: '¿Qué significa "book"?',
        answers: [
          'Casa',
          'Libro',
          'Mesa',
          'Escuela'
        ],
        correct: 1
      },
      {
        subject: 'Inglés',
        question: '¿Qué significa "school"?',
        answers: [
          'Escuela',
          'Amigo',
          'Libro',
          'Familia'
        ],
        correct: 0
      },
      {
        subject: 'Inglés',
        question: '¿Qué significa "friend"?',
        answers: [
          'Profesor',
          'Amigo',
          'Alumno',
          'Hermano'
        ],
        correct: 1
      }
    ]
  }

  if (type === 'math') {
    return shuffle(
      bank.math
    ).slice(0, 5)
  }

  if (type === 'science') {
    return shuffle(
      bank.science
    ).slice(0, 5)
  }

  if (type === 'word') {
    return shuffle([
      ...bank.communication,
      ...bank.english
    ]).slice(0, 5)
  }

  if (type === 'quiz') {
    return shuffle([
      ...bank.math,
      ...bank.science,
      ...bank.communication,
      ...bank.history,
      ...bank.english
    ]).slice(0, 6)
  }

  return shuffle([
    ...bank.math,
    ...bank.science,
    ...bank.communication,
    ...bank.history,
    ...bank.english
  ]).slice(0, 5)
}

function shuffle(array) {
  return [...array].sort(
    () => Math.random() - 0.5
  )
}

function finishGame(
  type,
  score,
  total
) {
  const xp = score * 10
  const coins = score * 3

  state.records[type] = Math.max(
    state.records[type] || 0,
    score
  )

  state.coins += coins

  updateStreak()
  addXP(xp)
  saveState()

  const area =
    document.querySelector('#gameArea')

  if (!area) return

  area.innerHTML = `
    <div class="game-result">

      <div class="result-trophy">
        🏆
      </div>

      <h2>
        ¡Reto terminado!
      </h2>

      <p>
        Conseguido:
        <strong>
          ${score}/${total}
        </strong>
      </p>

      <div class="result-rewards">

        ⭐ +${xp} XP

        <span>
          🪙 +${coins}
        </span>

      </div>

      <button
        class="primary-btn"
        onclick="navigate('juegos')"
      >
        🎮 Volver a juegos
      </button>

    </div>
  `
}

/* =========================================================
   MEMORIA
   ========================================================= */

function memoryGame(area) {
  const symbols = [
    '📚',
    '✏️',
    '🧠',
    '🎓',
    '🔬',
    '🏆'
  ]

  const cards = shuffle([
    ...symbols,
    ...symbols
  ])

  let first = null
  let lock = false
  let matched = 0

  area.innerHTML = `
    <div class="active-game">

      <div class="game-top">

        <span>
          🧩 Memoria
        </span>

        <span id="memoryCounter">
          Parejas: 0/${symbols.length}
        </span>

      </div>

      <div class="memory-grid">

        ${cards
          .map(
            (_, i) => `
              <button
                class="memory-card"
                data-index="${i}"
              >
                ?
              </button>
            `
          )
          .join('')}

      </div>

    </div>
  `

  const buttons = [
    ...area.querySelectorAll(
      '.memory-card'
    )
  ]

  buttons.forEach(
    (button, index) => {
      button.addEventListener(
        'click',
        () => {

          if (
            lock ||
            button.classList.contains(
              'matched'
            )
          ) {
            return
          }

          button.textContent =
            cards[index]

          if (first === null) {
            first = index
            return
          }

          if (
            cards[first] ===
            cards[index]
          ) {
            buttons[first]
              .classList.add(
                'matched'
              )

            button.classList.add(
              'matched'
            )

            matched++
            first = null

            addXP(10)

            const counter =
              document.querySelector(
                '#memoryCounter'
              )

            if (counter) {
              counter.textContent =
                `Parejas: ${matched}/${symbols.length}`
            }

            if (
              matched ===
              symbols.length
            ) {
              addCoins(15)

              showToast(
                '🎉 ¡Memoria completada! +15 monedas'
              )

              playFeedback(
                'success'
              )
            }
          } else {
            lock = true

            setTimeout(() => {
              buttons[first].textContent =
                '?'

              button.textContent =
                '?'

              first = null
              lock = false
            }, 750)
          }
        }
      )
    }
  )
}

/* =========================================================
   AVATAR
   ========================================================= */

function avatarPage() {
  const skinColors = [
    '#f1c29b',
    '#e8b28d',
    '#d99a72',
    '#c77d52',
    '#a95c35',
    '#8d5524',
    '#6d4c41'
  ]

  const hairColors = [
    '#21140e',
    '#3b2418',
    '#6d4c41',
    '#8b5a2b',
    '#d4a017',
    '#c45c3c',
    '#7b1fa2',
    '#2563eb'
  ]

  const clothesColors = [
    '#6d4aff',
    '#3478f6',
    '#1fa774',
    '#f59e0b',
    '#ef4444',
    '#ec4899',
    '#111827',
    '#ffffff',
    '#0ea5e9',
    '#14b8a6'
  ]

  const backgrounds = [
    '#eee7ff',
    '#e0f2fe',
    '#dcfce7',
    '#fef3c7',
    '#ffe4e6',
    '#e5e7eb'
  ]

  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          PERSONALIZACIÓN
        </span>

        <h2>
          👤 Mi avatar
        </h2>

        <p>
          Diseña un personaje único para tu espacio escolar.
        </p>

      </div>

    </div>

    <div class="avatar-editor">

      <section
        class="avatar-preview"
        style="
          background:${escapeHTML(
            state.avatar.background
          )}
        "
      >

        <div class="avatar-stars">
          ✦ ✧ ✦
        </div>

        ${avatarSVG(280)}

        <h3>
          Mi personaje
        </h3>

        <p>
          Nivel ${state.level}
        </p>

      </section>

      <section class="avatar-controls">

        <div class="custom-section">

          <h3>
            🎨 Color de piel
          </h3>

          <div class="color-grid">

            ${skinColors
              .map(
                color => `
                  <button
                    class="color-choice"
                    style="
                      background:${color}
                    "
                    title="${color}"
                    onclick="setAvatar(
                      'skin',
                      '${color}'
                    )"
                  ></button>
                `
              )
              .join('')}

          </div>

        </div>

        <div class="custom-section">

          <h3>
            💇 Estilo de cabello
          </h3>

          <div class="option-grid">

            <button
              onclick="setAvatar(
                'hairType',
                'spiky'
              )"
            >
              ⚡ Puntiagudo
            </button>

            <button
              onclick="setAvatar(
                'hairType',
                'short'
              )"
            >
              ✂️ Corto
            </button>

            <button
              onclick="setAvatar(
                'hairType',
                'curly'
              )"
            >
              🌀 Rizado
            </button>

            <button
              onclick="setAvatar(
                'hairType',
                'long'
              )"
            >
              💇 Largo
            </button>

          </div>

        </div>

        <div class="custom-section">

          <h3>
            🎨 Color del cabello
          </h3>

          <div class="color-grid">

            ${hairColors
              .map(
                color => `
                  <button
                    class="color-choice"
                    style="
                      background:${color}
                    "
                    onclick="setAvatar(
                      'hair',
                      '${color}'
                    )"
                  ></button>
                `
              )
              .join('')}

          </div>

        </div>

        <div class="custom-section">

          <h3>
            👕 Ropa
          </h3>

          <div class="option-grid">

            <button
              onclick="setAvatar(
                'shirtType',
                'hoodie'
              )"
            >
              🧥 Sudadera
            </button>

            <button
              onclick="setAvatar(
                'shirtType',
                'sports'
              )"
            >
              ⚽ Deportiva
            </button>

            <button
              onclick="setAvatar(
                'shirtType',
                'jacket'
              )"
            >
              🧢 Chaqueta
            </button>

            <button
              onclick="setAvatar(
                'shirtType',
                'uniform'
              )"
            >
              🎒 Uniforme
            </button>

          </div>

        </div>

        <div class="custom-section">

          <h3>
            👖 Color del pantalón
          </h3>

          <div class="color-grid">

            ${clothesColors
              .map(
                color => `
                  <button
                    class="color-choice"
                    style="
                      background:${color}
                    "
                    onclick="setAvatar(
                      'pants',
                      '${color}'
                    )"
                  ></button>
                `
              )
              .join('')}

          </div>

        </div>

        <div class="custom-section">

          <h3>
            🎨 Color de ropa
          </h3>

          <div class="color-grid">

            ${clothesColors
              .map(
                color => `
                  <button
                    class="color-choice"
                    style="
                      background:${color}
                    "
                    onclick="setAvatar(
                      'shirt',
                      '${color}'
                    )"
                  ></button>
                `
              )
              .join('')}

          </div>

        </div>

        <div class="custom-section">

          <h3>
            ✨ Accesorio principal
          </h3>

          <div class="option-grid">

            <button
              onclick="setAvatar(
                'accessory',
                'none'
              )"
            >
              🚫 Ninguno
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'glasses'
              )"
            >
              👓 Gafas
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'cap'
              )"
            >
              🧢 Gorra
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'headphones'
              )"
            >
              🎧 Audífonos
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'crown'
              )"
            >
              👑 Corona
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'headband'
              )"
            >
              🎀 Banda
            </button>

            <button
              onclick="setAvatar(
                'accessory',
                'visor'
              )"
            >
              🧢 Visera
            </button>

          </div>

        </div>

        <div class="custom-section">

          <h3>
            🎒 Accesorio adicional
          </h3>

          <div class="option-grid">

            <button
              onclick="setAvatar(
                'accessory2',
                'none'
              )"
            >
              🚫 Ninguno
            </button>

            <button
              onclick="setAvatar(
                'accessory2',
                'backpack'
              )"
            >
              🎒 Mochila
            </button>

            <button
              onclick="setAvatar(
                'accessory2',
                'star'
              )"
            >
              ⭐ Estrella
            </button>

            <button
              onclick="setAvatar(
                'accessory2',
                'badge'
              )"
            >
              🏅 Insignia
            </button>

            <button
              onclick="setAvatar(
                'accessory2',
                'tie'
              )"
            >
              👔 Corbata
            </button>

            <button
              onclick="setAvatar(
                'accessory2',
                'scarf'
              )"
            >
              🧣 Bufanda
            </button>

          </div>

        </div>

        <div class="custom-section">

          <h3>
            🌈 Fondo
          </h3>

          <div class="color-grid">

            ${backgrounds
              .map(
                color => `
                  <button
                    class="color-choice"
                    style="
                      background:${color}
                    "
                    onclick="setAvatar(
                      'background',
                      '${color}'
                    )"
                  ></button>
                `
              )
              .join('')}

          </div>

        </div>

      </section>

    </div>
  `
}

function setAvatar(property, value) {
  state.avatar[property] = value

  saveState()

  playFeedback('click')

  render()
}

/* =========================================================
   LIBRETA
   ========================================================= */

function notesPage() {
  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          TU ESPACIO PERSONAL
        </span>

        <h2>
          📖 Mi libreta
        </h2>

        <p>
          Guarda apuntes, ideas, fórmulas y recordatorios.
        </p>

      </div>

    </div>

    <div class="notes-layout">

      <section class="form-card">

        <h3>
          📝 Nuevo apunte
        </h3>

        <input
          id="noteTitle"
          placeholder="Título del apunte"
        >

        <select id="noteSubject">

          <option>
            General
          </option>

          ${materias
            .map(
              materia =>
                `<option>${materia}</option>`
            )
            .join('')}

        </select>

        <textarea
          id="noteContent"
          placeholder="Escribe aquí tus apuntes..."
        ></textarea>

        <button
          class="primary-btn"
          id="addNote"
        >
          💾 Guardar apunte
        </button>

      </section>

      <section class="notes-grid">

        ${
          state.notas.length === 0
            ? `
              <div class="big-empty">

                <div>
                  📓
                </div>

                <h3>
                  Tu libreta está vacía
                </h3>

                <p>
                  Aquí aparecerán tus apuntes.
                </p>

              </div>
            `
            : state.notas
                .map(
                  (note, index) => `
                    <article class="note-card">

                      <div class="note-icon">
                        📝
                      </div>

                      <div class="note-date">
                        ${escapeHTML(
                          note.date
                        )}
                        ·
                        ${escapeHTML(
                          note.time
                        )}
                      </div>

                      <small>
                        ${escapeHTML(
                          note.subject ||
                          'General'
                        )}
                      </small>

                      <h3>
                        ${escapeHTML(
                          note.title
                        )}
                      </h3>

                      <p>
                        ${escapeHTML(
                          note.content
                        )}
                      </p>

                      <button
                        class="delete-btn"
                        onclick="deleteNote(${index})"
                      >
                        🗑️ Eliminar
                      </button>

                    </article>
                  `
                )
                .join('')
        }

      </section>

    </div>
  `
}

function renderNotesEvents() {
  document
    .querySelector('#addNote')
    ?.addEventListener('click', () => {

      const title =
        document.querySelector('#noteTitle')
          ?.value
          .trim()

      const subject =
        document.querySelector('#noteSubject')
          ?.value

      const content =
        document.querySelector('#noteContent')
          ?.value
          .trim()

      if (!title || !content) {
        showToast(
          '📝 Completa el título y contenido'
        )

        return
      }

      const now = new Date()

      state.notas.unshift({
        id: Date.now(),
        title,
        subject,
        content,
        date: formatDate(now),
        time: formatTime(now)
      })

      saveState()

      addXP(5)
      updateStreak()

      showToast(
        '📖 Apunte guardado'
      )

      render()
    })
}

function deleteNote(index) {
  if (!state.notas[index]) return

  if (
    !confirm(
      '¿Quieres eliminar este apunte?'
    )
  ) {
    return
  }

  state.notas.splice(index, 1)

  saveState()

  showToast(
    '🗑️ Apunte eliminado'
  )

  render()
}

/* =========================================================
   BIENESTAR
   ========================================================= */

function wellnessPage() {
  const moods = [
    ['😊', 'Muy bien'],
    ['🙂', 'Bien'],
    ['😐', 'Normal'],
    ['😕', 'Algo preocupado'],
    ['😣', 'Día difícil']
  ]

  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          BIENESTAR
        </span>

        <h2>
          💙 ¿Cómo estás?
        </h2>

        <p>
          Este espacio es para hacer una pausa
          y reconocer cómo te sientes.
        </p>

      </div>

    </div>

    <div class="wellness-layout">

      <section class="wellness-card">

        <div class="wellness-scene">
          ☁️
          <span>☀️</span>
          <strong>🌱</strong>
          <div>🧑‍🎓</div>
        </div>

        <h3>
          ¿Cómo te sientes hoy?
        </h3>

        <div class="mood-large">

          ${moods
            .map(
              mood => `
                <button
                  class="
                    ${state.animo === mood[0]
                      ? 'selected'
                      : ''}
                  "
                  onclick="selectMood('${mood[0]}')"
                >

                  <span>
                    ${mood[0]}
                  </span>

                  <small>
                    ${mood[1]}
                  </small>

                </button>
              `
            )
            .join('')}

        </div>

      </section>

      <section class="wellness-card">

        <h3>
          📔 Registro del día
        </h3>

        <p>
          Puedes escribir qué pasó hoy,
          qué te gustó o qué te gustaría mejorar.
        </p>

        <textarea
          id="dailyJournal"
          placeholder="¿Cómo fue tu día?"
        ></textarea>

        <button
          class="primary-btn"
          onclick="saveJournal()"
        >
          💾 Guardar registro
        </button>

        <div class="journal-history">

          ${state.diario
            .slice(0, 5)
            .map(
              item => `
                <div>

                  <strong>
                    ${escapeHTML(
                      item.date
                    )}
                  </strong>

                  <p>
                    ${escapeHTML(
                      item.text
                    )}
                  </p>

                </div>
              `
            )
            .join('')}

        </div>

      </section>

    </div>

    <div class="support-card">

      💙 Si un problema te está afectando mucho,
      hablar con una persona adulta de confianza,
      un familiar, docente u orientador puede ayudarte.
      Pedir apoyo es una forma válida de cuidarte.

    </div>
  `
}

function renderWellnessEvents() {}

function selectMood(mood) {
  state.animo = mood

  saveState()
  updateStreak()
  addXP(2)

  showToast(
    `💙 Estado registrado: ${mood}`
  )

  render()
}

function quickMood(mood) {
  state.animo = mood

  saveState()
  updateStreak()
  addXP(2)

  showToast(
    `💙 Estado registrado: ${mood}`
  )

  render()
}

function saveJournal() {
  const input =
    document.querySelector(
      '#dailyJournal'
    )

  if (!input) return

  const text =
    input.value.trim()

  if (!text) {
    showToast(
      '📔 Escribe algo sobre tu día'
    )

    return
  }

  const now = new Date()

  state.diario.unshift({
    id: Date.now(),
    date: `${formatDate(now)} · ${formatTime(now)}`,
    text
  })

  saveState()
  updateStreak()
  addXP(5)

  showToast(
    '📔 Registro guardado'
  )

  render()
}

/* =========================================================
   CALENDARIO
   ========================================================= */

function calendarPage() {
  const year =
    currentCalendarDate.getFullYear()

  const monthIndex =
    currentCalendarDate.getMonth()

  const monthName =
    currentCalendarDate.toLocaleDateString(
      'es-PE',
      {
        month: 'long',
        year: 'numeric'
      }
    )

  const firstDay =
    new Date(
      year,
      monthIndex,
      1
    ).getDay()

  const offset =
    firstDay === 0
      ? 6
      : firstDay - 1

  const totalDays =
    new Date(
      year,
      monthIndex + 1,
      0
    ).getDate()

  const cells = []

  for (let i = 0; i < offset; i++) {
    cells.push(
      `<div class="calendar-day empty"></div>`
    )
  }

  for (
    let day = 1;
    day <= totalDays;
    day++
  ) {
    const key =
      `${year}-${String(
        monthIndex + 1
      ).padStart(2, '0')}-${String(
        day
      ).padStart(2, '0')}`

    const hasTask =
      state.tareas.some(
        task =>
          task.date === key
      )

    const today =
      key === todayKey()

    cells.push(`
      <div
        class="
          calendar-day
          ${today ? 'today' : ''}
          ${hasTask ? 'has-task' : ''}
        "
        title="${
          hasTask
            ? 'Tienes una tarea este día'
            : ''
        }"
      >
        ${day}
        ${
          hasTask
            ? '<span></span>'
            : ''
        }
      </div>
    `)
  }

  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          PLANIFICACIÓN
        </span>

        <h2>
          📅 Calendario
        </h2>

        <p>
          Revisa tus fechas importantes.
        </p>

      </div>

    </div>

    <section class="calendar-card">

      <div class="calendar-title">

        <button onclick="changeMonth(-1)">
          ‹
        </button>

        <h2>
          ${monthName}
        </h2>

        <button onclick="changeMonth(1)">
          ›
        </button>

      </div>

      <div class="calendar-week">

        <b>L</b>
        <b>M</b>
        <b>M</b>
        <b>J</b>
        <b>V</b>
        <b>S</b>
        <b>D</b>

      </div>

      <div class="calendar-days">
        ${cells.join('')}
      </div>

    </section>
  `
}

function changeMonth(amount) {
  currentCalendarDate.setMonth(
    currentCalendarDate.getMonth() +
      amount
  )

  render()
}

/* =========================================================
   PROGRESO
   ========================================================= */

function progressPage() {
  const totalTasks =
    state.tareas.length

  const completed =
    state.tareas.filter(
      task => task.completed
    ).length

  const completion =
    totalTasks === 0
      ? 0
      : Math.round(
          (completed / totalTasks) *
            100
        )

  const gamesPlayed =
    Object.values(
      state.records
    ).reduce(
      (sum, value) =>
        sum + Number(value || 0),
      0
    )

  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          TU PROGRESO
        </span>

        <h2>
          🏆 Mi progreso
        </h2>

        <p>
          Cada pequeño avance cuenta.
        </p>

      </div>

    </div>

    <div class="progress-grid">

      <div class="progress-big-card">
        <span>⭐</span>
        <strong>${state.xp}</strong>
        <small>XP actual</small>
      </div>

      <div class="progress-big-card">
        <span>🔥</span>
        <strong>${state.streak}</strong>
        <small>Racha</small>
      </div>

      <div class="progress-big-card">
        <span>🪙</span>
        <strong>${state.coins}</strong>
        <small>Monedas</small>
      </div>

      <div class="progress-big-card">
        <span>🎮</span>
        <strong>${gamesPlayed}</strong>
        <small>Mejoras registradas</small>
      </div>

    </div>

    <section class="progress-detail">

      <h3>
        📈 Nivel ${state.level}
      </h3>

      <div class="big-progress">
        <span
          style="
            width:${Math.min(
              100,
              (state.xp / xpNeeded()) *
                100
            )}%
          "
        ></span>
      </div>

      <p>
        ${state.xp} / ${xpNeeded()} XP
      </p>

      <h3>
        📚 Tareas completadas
      </h3>

      <div class="big-progress">
        <span
          style="
            width:${completion}%
          "
        ></span>
      </div>

      <p>
        ${completion}%
      </p>

    </section>
  `
}

/* =========================================================
   CONFIGURACIÓN
   ========================================================= */

function configPage() {
  return `
    <div class="section-header">

      <div>

        <span class="eyebrow">
          PERSONALIZACIÓN
        </span>

        <h2>
          ⚙️ Configuración
        </h2>

        <p>
          Ajusta StudyPro a tu manera.
        </p>

      </div>

    </div>

    <div class="settings-list">

      <div class="setting-row">

        <div>
          <strong>
            🌙 Modo oscuro
          </strong>

          <small>
            Cambia la apariencia de StudyPro.
          </small>
        </div>

        <label class="switch">

          <input
            type="checkbox"
            id="darkMode"
            ${state.settings.dark ? 'checked' : ''}
          >

          <span></span>

        </label>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            🔊 Sonidos
          </strong>

          <small>
            Sonidos de interacción.
          </small>
        </div>

        <label class="switch">

          <input
            type="checkbox"
            id="soundMode"
            ${state.settings.sound ? 'checked' : ''}
          >

          <span></span>

        </label>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            ✨ Animaciones
          </strong>

          <small>
            Efectos visuales de la aplicación.
          </small>
        </div>

        <label class="switch">

          <input
            type="checkbox"
            id="animationMode"
            ${state.settings.animations ? 'checked' : ''}
          >

          <span></span>

        </label>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            📐 Vista compacta
          </strong>

          <small>
            Reduce algunos espacios de la interfaz.
          </small>
        </div>

        <label class="switch">

          <input
            type="checkbox"
            id="compactMode"
            ${state.settings.compact ? 'checked' : ''}
          >

          <span></span>

        </label>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            🌎 Idioma
          </strong>

          <small>
            Idioma de la interfaz.
          </small>
        </div>

        <select id="languageSelect">

          <option
            ${state.settings.language === 'Español'
              ? 'selected'
              : ''}
          >
            Español
          </option>

          <option
            ${state.settings.language === 'English'
              ? 'selected'
              : ''}
          >
            English
          </option>

        </select>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            💾 Datos locales
          </strong>

          <small>
            Tus datos se guardan en este navegador.
          </small>
        </div>

        <span class="status-badge">
          ACTIVO
        </span>

      </div>

      <div class="setting-row">

        <div>
          <strong>
            🏫 StudyPro IA
          </strong>

          <small>
            Plataforma de estudio y organización escolar.
          </small>
        </div>

        <span>
          v4.0
        </span>

      </div>

      <div class="danger-zone">

        <h3>
          ⚠️ Zona de datos
        </h3>

        <p>
          Puedes borrar todo el progreso local
          de StudyPro y comenzar nuevamente.
        </p>

        <button
          class="danger-btn"
          onclick="resetApp()"
        >
          🗑️ Restablecer StudyPro
        </button>

      </div>

    </div>
  `
}

function renderConfigEvents() {
  document
    .querySelector('#darkMode')
    ?.addEventListener(
      'change',
      event => {

        state.settings.dark =
          event.target.checked

        saveState()
        render()
      }
    )

  document
    .querySelector('#soundMode')
    ?.addEventListener(
      'change',
      event => {

        state.settings.sound =
          event.target.checked

        saveState()

        showToast(
          event.target.checked
            ? '🔊 Sonidos activados'
            : '🔇 Sonidos desactivados'
        )
      }
    )

  document
    .querySelector('#animationMode')
    ?.addEventListener(
      'change',
      event => {

        state.settings.animations =
          event.target.checked

        saveState()

        showToast(
          '✨ Animaciones actualizadas'
        )

        render()
      }
    )

  document
    .querySelector('#compactMode')
    ?.addEventListener(
      'change',
      event => {

        state.settings.compact =
          event.target.checked

        saveState()
        render()
      }
    )

  document
    .querySelector('#languageSelect')
    ?.addEventListener(
      'change',
      event => {

        state.settings.language =
          event.target.value

        saveState()

        showToast(
          '🌎 Idioma actualizado'
        )
      }
    )
}

function resetApp() {
  if (
    !confirm(
      '¿Seguro que quieres borrar todos tus datos de StudyPro IA?'
    )
  ) {
    return
  }

  localStorage.removeItem(
    STORAGE_KEY
  )

  state = cloneDefault()
  currentPage = 'inicio'

  showToast(
    '🗑️ StudyPro se ha restablecido'
  )

  render()
}

/* =========================================================
   MENÚ
   ========================================================= */

function toggleMenu() {
  document
    .querySelector('.sidebar')
    ?.classList.toggle('open')

  document
    .querySelector('.mobile-overlay')
    ?.classList.toggle('show')
}

function navigate(page) {
  currentPage = page

  document
    .querySelector('.sidebar')
    ?.classList.remove('open')

  document
    .querySelector('.mobile-overlay')
    ?.classList.remove('show')

  render()

  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  })
}

/* =========================================================
   FUNCIONES GLOBALES PARA LOS BOTONES HTML
   ========================================================= */

window.navigate = navigate
window.toggleMenu = toggleMenu
window.startGame = startGame
window.toggleTask = toggleTask
window.deleteTask = deleteTask
window.deleteNote = deleteNote
window.setAvatar = setAvatar
window.selectMood = selectMood
window.quickMood = quickMood
window.saveJournal = saveJournal
window.tutorExample = tutorExample
window.resetApp = resetApp
window.changeMonth = changeMonth

/* =========================================================
   INICIO
   ========================================================= */

updateStreak()
render()